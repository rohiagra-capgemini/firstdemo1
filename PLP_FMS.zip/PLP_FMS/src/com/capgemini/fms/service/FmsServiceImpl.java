package com.capgemini.fms.service;

import com.capgemini.fms.bean.Course;
import com.capgemini.fms.bean.Faculty;
import com.capgemini.fms.dao.FmsDaoImpl;
import com.capgemini.fms.dao.IFmsDao;

public class FmsServiceImpl implements FmsService {

	IFmsDao fmsDao = new FmsDaoImpl();
	@Override
	public String doLogin(int userId, String password) {
		
		return fmsDao.doLogin(userId, password);
	}
	@Override
	public Faculty getFacultyDetails(int id) {
		return fmsDao.getFacultyDetails(id);
	}
	@Override
	public int updateSkills(Faculty faculty) {
		// TODO Auto-generated method stub
		return fmsDao.updateSkills(faculty);
	}
	@Override
	public int addCourse(Course course) {
		// TODO Auto-generated method stub
		return fmsDao.addCourse(course);
	}
	@Override
	public boolean removeCourse(int courseId) {
		// TODO Auto-generated method stub
		return fmsDao.removeCourse(courseId);
	}
	@Override
	public Course getCourseDetails(int courseId) {
		// TODO Auto-generated method stub
		return fmsDao.getCourseDetails(courseId);
	}
	@Override
	public boolean updateCourse(Course course) {
		// TODO Auto-generated method stub
		return fmsDao.updateCourse(course);
	}

}
