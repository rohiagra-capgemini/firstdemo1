package com.capgemini.fms.dao;

public interface QueryMapper {

	public static final String LOGIN_QUERY = "SELECT e.Role from EMPLOYEE_MASTER e where"
			+ " e.EMPLOYEE_ID = ? AND e.PASSWORD = ?";
	public static final String FACULTY_DETAILS_QUERY = "SELECT f.skill_set FROM FACULTY_SKILL f WHERE"
			+ " f.FACULTY_ID=?";
	public static final String UPDATE_FACULTY_SKILLS = "UPDATE FACULTY_SKILL "
			+ "SET SKILL_SET= ? WHERE FACULTY_ID=?";
	public static final String ADD_COURSE = "INSERT INTO COURSE_MASTER VALUES(?,?,?)";
	public static final String DELETE_COURSE ="DELETE FROM COURSE_MASTER WHERE COURSE_ID =?";
	public static final String VIEW_COURSE = "SELECT c.COURSE_ID, c.COURSE_NAME, c.NO_OF_DAYS FROM COURSE_MASTER c WHERE c.COURSE_ID = ?";
	public static final String UPDATE_COURSE = "UPDATE COURSE_MASTER SET NO_OF_DAYS = ? "
			+ "WHERE COURSE_ID =?";
}
