package com.capgemini.fms.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil {

	public static Connection getConnection() {
		Connection conn = null;
		FileInputStream fs = null;

		try {
			fs = new FileInputStream(
					"C:/Users/rohiagra/workspace/PLP_FMS/resources/jdbc.properties");
			Properties prop = new Properties();
			prop.load(fs);
			conn = DriverManager.getConnection(prop.getProperty("dburl"),
					prop.getProperty("username"), prop.getProperty("password"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return conn;

	}
}
