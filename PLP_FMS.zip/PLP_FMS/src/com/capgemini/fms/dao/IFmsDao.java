package com.capgemini.fms.dao;

import com.capgemini.fms.bean.Course;
import com.capgemini.fms.bean.Faculty;

public interface IFmsDao {

	String doLogin(int userId, String password);

	Faculty getFacultyDetails(int id);

	int updateSkills(Faculty faculty);

	int addCourse(Course course);

	boolean removeCourse(int courseId);

	Course getCourseDetails(int courseId);

	boolean updateCourse(Course course);

}
