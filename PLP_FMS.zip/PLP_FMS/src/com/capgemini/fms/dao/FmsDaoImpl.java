package com.capgemini.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.fms.bean.Course;
import com.capgemini.fms.bean.Faculty;

public class FmsDaoImpl implements IFmsDao {

	PreparedStatement pstmt;
	int success = 0;
	private Faculty faculty = new Faculty();
	private Course course = new Course();
	Connection conn = DBUtil.getConnection();

	@Override
	public String doLogin(int userId, String password) {
		String role = null;
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(QueryMapper.LOGIN_QUERY);
			pstmt.setInt(1, userId);
			pstmt.setString(2, password);
			ResultSet res = pstmt.executeQuery();
			if (res.next()) {
				role = res.getString(1);
				return role;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return role;
	}

	@Override
	public Faculty getFacultyDetails(int id) {
		PreparedStatement pstmt;
		faculty = new Faculty();
		try {
			pstmt = conn.prepareStatement(QueryMapper.FACULTY_DETAILS_QUERY);
			pstmt.setInt(1, id);

			ResultSet res = pstmt.executeQuery();
			if (res.next()) {
				faculty.setFacultyId(id);
				faculty.setSkillSet(res.getString(1));
				return faculty;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return faculty;

	}

	@Override
	public int updateSkills(Faculty faculty) {
		PreparedStatement pstmt;
		
		int success = 0;
		try {
			pstmt = conn.prepareStatement(QueryMapper.UPDATE_FACULTY_SKILLS);
			pstmt.setString(1, faculty.getSkillSet());
			pstmt.setInt(2, faculty.getFacultyId());
			success = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return success;
	}

	@Override
	public int addCourse(Course course) {
		try {
			pstmt = conn.prepareStatement(QueryMapper.ADD_COURSE);
			pstmt.setInt(1, course.getCourseId());
			pstmt.setString(2, course.getCourseName());
			pstmt.setInt(3, course.getNoOfDays());
			success = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return success;
	}

	@Override
	public boolean removeCourse(int courseId) {
		try {
			pstmt = conn.prepareStatement(QueryMapper.DELETE_COURSE);
			pstmt.setInt(1, courseId);
			success = pstmt.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
	}

	@Override
	public Course getCourseDetails(int courseId) {
		try {
			pstmt = conn.prepareStatement(QueryMapper.VIEW_COURSE);
			pstmt.setInt(1, courseId);
			
			ResultSet res = pstmt.executeQuery();
			if(res.next()){
				course.setCourseId(res.getInt(1));
				course.setCourseName(res.getString(2));
				course.setNoOfDays(res.getInt(3));
				return course;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return course;
	}

	@Override
	public boolean updateCourse(Course course) {
		try {
			pstmt = conn.prepareStatement(QueryMapper.UPDATE_COURSE);
			pstmt.setInt(1, course.getNoOfDays());
			pstmt.setInt(2, course.getCourseId());
			pstmt.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

}
