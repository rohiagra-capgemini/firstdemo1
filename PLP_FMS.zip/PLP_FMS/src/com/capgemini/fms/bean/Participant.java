package com.capgemini.fms.bean;

public class Participant {

	private int trainingCode;
	private int participantId;
	public int getTrainingCode() {
		return trainingCode;
	}
	public void setTrainingCode(int trainingCode) {
		this.trainingCode = trainingCode;
	}
	public int getParticipantId() {
		return participantId;
	}
	public void setParticipantId(int participantId) {
		this.participantId = participantId;
	}
	@Override
	public String toString() {
		return "Participant [trainingCode=" + trainingCode + ", participantId="
				+ participantId + "]";
	}
	public Participant(int trainingCode, int participantId) {
		this.trainingCode = trainingCode;
		this.participantId = participantId;
	}
	public Participant() {
	}
	
	
}
