package com.capgemini.fms.bean;

import java.sql.Date;

public class Training {

	private int trainingCode;
	private String courseCode;
	private String facultyCode;
	private Date startDate;
	private Date endDate;
	public int getTrainingCode() {
		return trainingCode;
	}
	public void setTrainingCode(int trainingCode) {
		this.trainingCode = trainingCode;
	}
	public String getCourseCode() {
		return courseCode;
	}
	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}
	public String getFacultyCode() {
		return facultyCode;
	}
	public void setFacultyCode(String facultyCode) {
		this.facultyCode = facultyCode;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	@Override
	public String toString() {
		return "Training [trainingCode=" + trainingCode + ", courseCode="
				+ courseCode + ", facultyCode=" + facultyCode + ", startDate="
				+ startDate + ", endDate=" + endDate + "]";
	}
	public Training(int trainingCode, String courseCode, String facultyCode,
			Date startDate, Date endDate) {
		this.trainingCode = trainingCode;
		this.courseCode = courseCode;
		this.facultyCode = facultyCode;
		this.startDate = startDate;
		this.endDate = endDate;
	}
	public Training() {
	}
	
	
}
