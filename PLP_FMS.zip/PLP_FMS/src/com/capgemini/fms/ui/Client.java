package com.capgemini.fms.ui;

import java.util.Scanner;

import com.capgemini.fms.bean.Course;
import com.capgemini.fms.bean.Faculty;
import com.capgemini.fms.service.FmsService;
import com.capgemini.fms.service.FmsServiceImpl;

public class Client {

	static Scanner sc = new Scanner(System.in);
	static FmsService fmsService = new FmsServiceImpl();
	static int userId;
	public static void main(String[] args) {
		
		String role = login();
		if(role.equalsIgnoreCase("admin")){
			viewAdminPage();
		}
		else if(role.equalsIgnoreCase("coordinator")){
			//viewCoordinatorPage();
		}
		else if(role.equalsIgnoreCase("participant")){
			//viewParticpantPage();
		}
		else{
			
		}
	}
	
	public static String login(){
		System.out.println("Please enter your Employee ID:");
		userId = sc.nextInt();
		System.out.println("Please enter your password:");
		String password = sc.next();

		String role = fmsService.doLogin(userId, password);
		return role;
	}
	
	public static void viewAdminPage(){
		Faculty faculty = new Faculty();
		System.out.println("What do you want to do?");
		System.out.println("1. Faculty Skill Maintenance");
		System.out.println("2. Course Maintenance");
		System.out.println("3. View Feedback Report");
		int choice = sc.nextInt();
		if(choice == 1){
			System.out.println("Enter faculty ID:");
			int id = sc.nextInt();
			faculty = fmsService.getFacultyDetails(id);
			System.out.println(faculty);
			System.out.println("Enter the new skill set");
			String skills = sc.next();
			skills = skills +"," + faculty.getSkillSet();
			faculty.setSkillSet(skills);
			int success = fmsService.updateSkills(faculty);
			System.out.println(success);
		}
		else if(choice == 2){
			Course course = new Course();
			System.out.println("1. Add Course");
			System.out.println("2. Delete Course");
			System.out.println("3. Modify Course");
			int option = sc.nextInt();
			switch(option){
			case 1: 
				System.out.println("Enter Course ID");
				course.setCourseId(sc.nextInt());;
				System.out.println("Enter Course Name");
				course.setCourseName(sc.next());
				System.out.println("Enter No. of Days");
				course.setNoOfDays(sc.nextInt());
				int success = fmsService.addCourse(course);
				if(success == 1)
					System.out.println("Course Added");
				break;
			
			case 2:
				System.out.println("Enter course ID for the course to be deleted");
				int courseId = sc.nextInt();
				boolean succ = fmsService.removeCourse(courseId);
				if(succ){
					System.out.println("Course deleted successfully.");
				}
				else{
					System.out.println("Course does not exist");
				}
				break;
				
			case 3:
				System.out.println("Enter course ID for the course to be modified");
				courseId = sc.nextInt();
				course = fmsService.getCourseDetails(courseId);
				if(course == null){
					System.out.println("Course does not exist");
				}
				else{
					System.out.println(course);
					System.out.println("Enter the modified number of days for this course");
					course.setNoOfDays(sc.nextInt());
					System.out.println(course);
					succ = fmsService.updateCourse(course);
					if(succ){
						System.out.println("Course updated successfully");
					}
					else{
						System.out.println("Error occured");
					}
				}
				break;
				
				default:
					System.out.println("Program exiting. Invalid choice");
					System.exit(0);
			}
		}
		/*else if(choice == 3){
			System.out.println("Which feedback report do you want to see?");
			System.out.println("1. All training program report");
			System.out.println("2. Faculty Wise training report");
			System.out.println("3. Feedback Defaulters report");
			int option = sc.nextInt();
			switch(option){
			case 1:
				fmsService.getTrainingProgramReport();
				break;
			case 2: 
				break;
			}
		}*/
		else{
			System.out.println("Exit");
		}
	}
}


